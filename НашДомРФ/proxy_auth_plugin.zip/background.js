
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "pool.proxy.market",
            port: parseInt(10000)
        },
        bypassList: ["localhost"]
    }
};

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

chrome.webRequest.onAuthRequired.addListener(
    function(details) {
        return {
            authCredentials: {
                username: "oQwU7eENkWPX",
                password: "zAY2hFH04gE5LmMK"
            }
        };
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);
